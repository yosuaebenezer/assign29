package com.assign29_RestAPI.CRUD.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyAppApplication { // Perbaiki penamaan kelas untuk konsistensi

	public static void main(String[] args) {
		SpringApplication.run(MyAppApplication.class, args); // Sesuaikan dengan nama kelas
	}

}